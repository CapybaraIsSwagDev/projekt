# velmi basic webserver
# Potrebuje Moduly flask, flask_cors
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from flask import Flask, request
from flask_cors import CORS, cross_origin

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'


@app.route('/')
def hello_world():
    return 'Tu nemas co robit :D'

sender = "stastnazabkagab@gmail.com"
password = "" # Tu sa da heslo pre gmail


def send_email(subject, html, sender, recipients, password):
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = ', '.join(recipients)
    msg.attach(MIMEText(html, "html"))
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp_server:
       smtp_server.login(sender, password)
       smtp_server.sendmail(sender, recipients, msg.as_string())
    print("Message sent!")

def druha(meno,priezvisko,mail):
    try:
        meno = str(meno)
        priezvisko = str(priezvisko)
        mail = str(mail)
    except:
        print("error")
        return "error", 400
    html = f"""
    <html>
      <body>
        <h2>Štastná žabka</h2>

        <p>Dobrý deň {meno} {priezvisko},</p>

        <p>
            Ďakujeme za váš záujem o prácu v našej spoločnosti.
        </p>

        <p>
            Budeme vás čoskoro kontaktovať.
        </p>

        <br>

        <p>S pozdravom,<br>
        Štastná žabka</p>
      </body>
    </html>
    """
    subject = "Štastná žabka"
    recipients = [mail]
    send_email(subject,html,sender,recipients,password)
    return "dobre", 200 

#send_email(subject, body, sender, recipients, password)



@app.route('/new', methods=['GET', 'POST'])
@cross_origin()
def new():
    print("new")
    if request.method == 'POST':
        meno = request.form.get('meno')
        priezvisko = request.form.get('priezvisko')
        mail = request.form.get('mail')
        if meno and priezvisko and mail:
            return druha(meno,priezvisko,mail)
        return "error", 400
    else:
        return "Tato lokalita je ibe pre metodu POST nie GET"
